﻿namespace GroceriesManagement
{
    public class GroceriesStore
    {
        private List<Product> Stall;
        public int Capacity { get; private set; }
        public double Turnover { get; private set; }

        public GroceriesStore(int capacity)
        {
            Capacity = capacity;
            Turnover = 0;
            Stall = new List<Product>();
        }

        public bool AddProduct(Product product)
        {
            if (Stall.Count < Capacity && !Stall.Any(p => p.Name == product.Name))
            {
                Stall.Add(product);
                return true;
            }
            return false;
        }

        public bool RemoveProduct(string name)
        {
            var product = Stall.FirstOrDefault(p => p.Name == name);
            if (product != null)
            {
                Stall.Remove(product);
                return true;
            }
            return false;
        }

        public string SellProduct(string name, double quantity)
        {
            var product = Stall.FirstOrDefault(p => p.Name == name);
            if (product == null)
            {
                return "Product not found";
            }
            double totalPrice = product.Price * quantity;
            Turnover += totalPrice;
            return $"{name} - {totalPrice:F2}$";
        }

        public string GetMostExpensive()
        {
            if (Stall.Count == 0) return null;
            return Stall.OrderByDescending(p => p.Price).First().ToString();
        }

        public string CashReport()
        {
            return $"Total Turnover: {Turnover:F2}$";
        }

        public string PriceList()
        {
            return "Groceries Price List:\n" + string.Join("\n", Stall.Select(p => p.ToString()));
        }
    }
}
